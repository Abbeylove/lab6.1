﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QABank
{
    class Payee
    {
        private string name, address;
        private DateTime date;
        private double amount;
    }
}
